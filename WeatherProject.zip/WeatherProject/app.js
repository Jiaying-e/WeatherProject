const express = require("express");
const https = require("https");
const app = express();

app.get("/", function(req, res){

  const url = "https://api.openweathermap.org/data/2.5/weather?q=Beijing&appid=84cd50038ca4045ae76729e1d35f1d6f&units=metric"
  https.get(url, function(response){
    console.log(response.statusCode);

    response.on("data", function(data){
      console.log(data);
      const weatherData = JSON.parse(data)
      const description = weatherData.weather[0].description
      console.log(description);
    });

  });
  res.send("Server is running")
} );

app.listen(3000, function(){
  console.log("Server is running on port 3000.");
});
